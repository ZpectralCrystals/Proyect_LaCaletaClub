export *from "./Inicio";
export *from "./Blog";

export *from "./Contacto";
export *from "./Recomendaciones";
export *from "./Menu";

