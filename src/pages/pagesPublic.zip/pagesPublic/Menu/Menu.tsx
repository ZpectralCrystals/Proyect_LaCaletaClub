import React from 'react';
import MenuList from '@/components/MenuList/MenuList';

const Menu: React.FC = () => {
  return (
    <MenuList/>
  );
};

export default Menu;
