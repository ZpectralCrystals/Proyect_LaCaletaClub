export { default as Blog } from "./Blog/Blog";
export { default as Contacto } from "./Contacto/Contacto";
export { default as Inicio } from "./Inicio/Inicio";
export { default as Menu } from "./Menu/Menu";
export { default as Recomendaciones } from "./Recomendaciones/Recomendaciones";
export { default as Register } from "./Register/Register";
export { default as Login } from "./Login/Login";

