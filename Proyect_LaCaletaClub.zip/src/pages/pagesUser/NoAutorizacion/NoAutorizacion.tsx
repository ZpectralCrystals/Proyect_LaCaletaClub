export default function NoAutorizacion() {
    return(
        <>
        no tienes autorizacion para ingresar aqui
        
        </>
    )
}