import React from 'react';
import CarritoList from '../../components/CarritoList/CarritoList';

const Carrito: React.FC = () => {
  return (
    <CarritoList/>
  );
};

export default Carrito;
