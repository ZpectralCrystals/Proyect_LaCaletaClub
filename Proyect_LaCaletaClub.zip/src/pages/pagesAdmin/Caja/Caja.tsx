export default function CajaAdmin() {
    return(
        <>
        Caja
        </>
    )
}