export default function ReportesAdmin() {
    return(
        <>
        Reportes
        </>
    )
}