export default function InicioAdmin() {
    return(
        <>
        </>
    )
}