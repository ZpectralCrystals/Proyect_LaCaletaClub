export default function CommentsAdmin() {
    return(
        <>
        Comentarios
        </>
    )
}