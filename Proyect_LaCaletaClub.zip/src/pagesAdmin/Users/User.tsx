export default function UsuariosAdmin() {
    return(
        <>
        Ver usuarios
        </>
    )
}