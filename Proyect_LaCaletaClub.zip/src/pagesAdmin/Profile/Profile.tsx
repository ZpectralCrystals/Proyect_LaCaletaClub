export default function ProfileAdmin() {
    return(
        <>
        Perfil
        </>
    )
}