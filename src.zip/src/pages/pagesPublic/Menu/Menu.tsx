import MenuList from '@/components/MenuList/MenuList';

const Menu = () => {
  return (
    <MenuList/>
  );
};

export default Menu;
