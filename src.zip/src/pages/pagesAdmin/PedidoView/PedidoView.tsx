export default function PedidoView() {
    return(
        <>
        Vista de Pedidos
        </>
    )
}