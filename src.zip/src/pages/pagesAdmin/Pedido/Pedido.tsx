export default function Pedido() {
    return(
        <>
        Pedidos
        </>
    )
}