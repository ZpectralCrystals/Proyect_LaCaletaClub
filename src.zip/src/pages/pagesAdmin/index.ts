export { default as Category } from "./Category";
export { default as Discounts } from "./Discounts/Discounts";
export { default as Products } from "./Products/Products";
export { default as Profile } from "./Profile/Profile";
export { default as InicioAdmin } from "./Inicio/Inicio";
export { default as UsuariosAdmin } from "./Users/Users";
export { default as CommentsAdmin } from "./Comments/Comments";
export { default as RecomendacionesAdmin } from "./Recomendaciones/Recomendaciones";
export { default as ReportesAdmin } from "./Reportes/Reportes";





