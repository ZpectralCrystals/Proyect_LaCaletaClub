export default function ImagesCharge() {
    return(
        <>
        Carga de Imagenes
        </>
    )
}